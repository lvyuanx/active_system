const {chromium}=require('C:/Users/Administrator/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
(async()=>{
 const browser=await chromium.launch({headless:true,executablePath:'C:/Users/Administrator/AppData/Local/ms-playwright/chromium-1187/chrome-win/chrome.exe'});
 try {
  const page=await browser.newPage({viewport:{width:390,height:844},ignoreHTTPSErrors:true});
  await page.goto('https://127.0.0.1:18443/user/');
  await page.waitForTimeout(200);
  const dimensions=await page.evaluate(()=>({scroll:document.documentElement.scrollWidth,width:innerWidth}));
  if(dimensions.scroll>dimensions.width) throw Error('horizontal overflow');
  await page.screenshot({path:process.argv[2]+'/mobile-user.png'});
  console.log(JSON.stringify(dimensions));
 } finally {await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1});
