import importlib.util
from pathlib import Path
import subprocess
ROOT = Path(__file__).resolve().parents[3]
spec = importlib.util.spec_from_file_location('proxy', ROOT / 'deploy/tests/run_proxy_qa.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
original = subprocess.run
def run(args, **kwargs):
    if args[0] == 'node':
        args = ['node', str(ROOT / 'deploy/runtime/test-qa/mobile.cjs'), str(module.OUT)]
    return original(args, **kwargs)
subprocess.run = run
module.main()
