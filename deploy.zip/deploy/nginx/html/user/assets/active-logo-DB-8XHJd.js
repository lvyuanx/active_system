const o="/user/assets/active-logo-BNcWy6S9.png";export{o as a};
